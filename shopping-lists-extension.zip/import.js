'use strict';

let parsedData = null;

const dropZone  = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const status    = document.getElementById('status');
const importBtn = document.getElementById('importBtn');
const dropLabel = document.getElementById('dropLabel');

function showStatus(msg, ok) {
  status.textContent = msg;
  status.className = 'status ' + (ok ? 'ok' : 'err');
}

function normalise(parsed) {
  // nextId
  let maxId = parsed.nextId || 0;
  parsed.folders.forEach(function(f) {
    if (f.id > maxId) maxId = f.id;
    if (!Array.isArray(f.products)) f.products = [];
    f.products.forEach(function(p) {
      if (p.id > maxId) maxId = p.id;
      if (!('url'     in p)) p.url     = '';
      if (!('img'     in p)) p.img     = '';
      if (!('checked' in p)) p.checked = false;
    });
  });
  parsed.nextId = maxId + 1;

  // activeId
  const validActive = parsed.folders.some(function(f) { return f.id === parsed.activeId; });
  if (!validActive && parsed.folders.length > 0) {
    parsed.activeId = parsed.folders[0].id;
  }
  return parsed;
}

function processFile(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(ev) {
    try {
      const parsed = JSON.parse(ev.target.result);
      if (!parsed.folders || !Array.isArray(parsed.folders)) {
        throw new Error("Champ 'folders' manquant ou invalide");
      }
      parsedData = parsed;
      dropLabel.textContent = '✅ ' + file.name;
      const nb = parsed.folders.length;
      const nbP = parsed.folders.reduce(function(s, f) { return s + (f.products ? f.products.length : 0); }, 0);
      showStatus('Fichier valide — ' + nb + ' dossier(s), ' + nbP + ' produit(s). Cliquez sur Importer.', true);
      importBtn.disabled = false;
    } catch(e) {
      parsedData = null;
      importBtn.disabled = true;
      showStatus('Fichier invalide : ' + e.message, false);
    }
  };
  reader.onerror = function() {
    showStatus('Erreur de lecture du fichier.', false);
  };
  reader.readAsText(file);
}

// Clic sur la drop zone → ouvre le sélecteur de fichier
dropZone.addEventListener('click', function(e) {
  if (e.target !== fileInput) fileInput.click();
});

fileInput.addEventListener('change', function(e) {
  processFile(e.target.files[0]);
});

// Drag & drop
dropZone.addEventListener('dragover', function(e) {
  e.preventDefault();
  dropZone.classList.add('drag-over');
});
dropZone.addEventListener('dragleave', function() {
  dropZone.classList.remove('drag-over');
});
dropZone.addEventListener('drop', function(e) {
  e.preventDefault();
  dropZone.classList.remove('drag-over');
  processFile(e.dataTransfer.files[0]);
});

// Import
importBtn.addEventListener('click', function() {
  if (!parsedData) return;
  importBtn.disabled = true;
  importBtn.textContent = 'Enregistrement…';

  const ready = normalise(parsedData);

  browser.storage.local.set({ sl2_state: JSON.stringify(ready) })
    .then(function() {
      showStatus('✅ Import réussi ! Fermez cet onglet et rouvrez l\'extension.', true);
      importBtn.textContent = 'Importé ✅';
    })
    .catch(function(err) {
      showStatus('Erreur lors de la sauvegarde : ' + (err && err.message ? err.message : err), false);
      importBtn.disabled = false;
      importBtn.textContent = 'Importer';
    });
});
